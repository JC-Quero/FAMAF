#include <stdio.h>
#include <stdbool.h>
int main(void){
   
    //CICLOS
    //5) a)

    int i = 0;
    int es = 0;

    printf("Ingrese un valor para i : \n");
    scanf("%d", &i);

    printf("El estado inicial de i es: %d\n", i);

    while(i!= 0){
        es++;
        printf("o1 %d i = %d", es, i);
        i = i - 1;
        printf("o2 %d i = %d\n", es, i);
    }
    printf("o3 i = %d\n", i);

        
    

    //Ejecucion
    /*
        Ingrese un valor para i :
        4
        El estado inicial de i es: 4
        o1 1 i = 4o2 1 i = 3
        o1 2 i = 3o2 2 i = 2
        o1 3 i = 2o2 3 i = 1
        o1 4 i = 1o2 4 i = 0
        o3 i = 0
    
    */

    //ejecicio i

    printf("Ingrese un valor para i : \n");
    scanf("%d", &i);

    printf("El estado inicial de i es: %d\n", i);

    while(i!= 0){
        es++;
        printf("o1 %d i = %d", es, i);
        i = 0;
        printf("o2 %d i = %d\n", es, i);
    }
    printf("o3 i = %d\n", i);

    return 0;
    
    /*Ingrese un valor para i :
        400
        El estado inicial de i es: 400
        o1 1 i = 400o2 1 i = 0
        o3 i = 0 
    */

    //CICLOS EJERCICIOS B

    int x,y;

    printf("Ingrese el valor de x: ");
    scanf("%d", &x);

    printf("Ingrese el valor de y: ");
    scanf("%d", &y);

    printf("Ingrese el valor de i: ");
    scanf("%d", &i);

    printf("o0 sus estados iniciales son: %d,%d,%d\n",x,y,i);
    i = 0;

    while(x >= y){

        x = x - y;
        i = i + 1;
        printf("o1 %d, sus estados si x >= y: %d,%d,%d\n",i,x,y,i);

    }

    /*(Ejecucion)
    Ingrese el valor de x: 13
    Ingrese el valor de y: 3
    Ingrese el valor de i: 16
    o0 sus estados iniciales son: 13,3,16
    o1 1, sus estados si x >= y: 10,3,1
    o1 2, sus estados si x >= y: 7,3,2
    o1 3, sus estados si x >= y: 4,3,3
    o1 4, sus estados si x >= y: 1,3,4
    */

    //B2

    int TempRes;
    bool res;
    
    printf("Ingrese un valor para x: ");
    scanf("%d", &x);

    printf("Ingrese un valor para i: ");
    scanf("%d", &i);

    printf("Ingrese un valor para res: ");
    scanf("%d", &TempRes);
    res = TempRes;

    printf("o0 %d Sus estados iniciales son: %d,%d,%d\n",es,x,i,res);

    i = 2;
    res = true;

    while(i<x && res){  
        res = res && ((x % i) != 0);
        i = i + 1;
        es = es + 1;
        printf("o1 %d, Sus estados queda como : %d,%d,%d\n", es,x,i,res);
    }

    return 0;

    /*(Ejecucion)
    Ingrese un valor para x: 5
    Ingrese un valor para i: 0
    Ingrese un valor para res: false
    o0 0 Sus estados iniciales son: 5,0,1
    o1 1, Sus estados queda como : 5,3,1
    o1 2, Sus estados queda como : 5,4,1
    o1 3, Sus estados queda como : 5,5,1
    */
}