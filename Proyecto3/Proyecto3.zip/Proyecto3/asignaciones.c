#include <stdio.h>
int main(void){
    int x = 0;

    //Ejercicio 1.a
    printf("Ingrese un valor de x : \n");
    scanf("%d", &x);
   
    printf("El estado de x es = %d\n", x);
    x = 5;
    printf("Ahora el estado de x es = %d\n", x);
    
    /*Ejercicio a
    (Primera Ejec)
    Ingrese un valor de x :
    3
    El estado de x es = 3
    Ahora el estado de x es = 5

    (Segunda ejecucion)
    Ingrese un valor de x :
    19
    El estado de x es = 19
    Ahora el estado de x es = 5

    (Tercera Ejecucion)
    Ingrese un valor de x :
    920
    El estado de x es = 920
    Ahora el estado de x es = 5
    */

   //Ejercicio b

    int y = 0 ;

    printf("Ingrese el valor del estado de x :\n");
    scanf("%d",&x);
    printf("Ingrese el valor del estado de y: \n");
    scanf("%d",&y);

    printf("Los estados iniciales de x e y son= %d,%d\n", x,y);

    x = x + y;

    printf("Los estados despues de la asignacion x = x + y son : %d,%d\n", x,y);

    y = y + y;

    printf("Los estados despues de la asignacion y = y + y son : %d,%d\n", x,y);

    /*Ejercicio b

        (Primera ejecucion)

            Ingrese el valor del estado de x :
            2
            Ingrese el valor del estado de y:
            2
            Los estados iniciales de x e y son= 2,2
            Los estados despues de la asignacion x = x + y son : 4,2
            Los estados despues de la asignacion y = y + y son : 4,4

        (Segunda Ejecucion)
            Ingrese el valor del estado de x :
            1
            Ingrese el valor del estado de y:
            3
            Los estados iniciales de x e y son= 1,3
            Los estados despues de la asignacion x = x + y son : 4,3
            Los estados despues de la asignacion y = y + y son : 4,6

        (Tercera Ejecucion)
            Ingrese el valor del estado de x :
            4
            Ingrese el valor del estado de y:
            6
            Los estados iniciales de x e y son= 4,6
            Los estados despues de la asignacion x = x + y son : 10,6
            Los estados despues de la asignacion y = y + y son : 10,12


    */



    //Ejercico 1.c (Usamos a como x)
    int a = 0;

    printf("Ingrese su valor a \n");
    scanf("%d", &a);
    printf("Ingrese su valor y: \n");
    scanf("%d", &y);

    printf("Su estado inicial es = %d, %d\n", a, y);

    y = y + y;

    printf("Su estado ahora de: y = y + y  = %d, %d \n", a , y);

    a = a + 1;

    printf("Su estado ahora de: x = x + 1 = %d, %d \n", a , y);

    return 0;
    /*Ejercicio c

        (Primera Ejecucion)
        Ingrese su valor a
        1
        Ingrese su valor y:
        2
        Su estado inicial es = 1, 2
        Su estado ahora de: y = y + y  = 1, 4
        Su estado ahora de: x = x + 1 = 2, 4

        (Segunda Ejecucion)
        Ingrese su valor a
        3
        Ingrese su valor y:
        3
        Su estado inicial es = 3, 3
        Su estado ahora de: y = y + y  = 3, 6
        Su estado ahora de: x = x + 1 = 4, 6

        (Tercera Ejecucion)
        Ingrese su valor a
        4
        Ingrese su valor y:
        2
        Su estado inicial es = 4, 2
        Su estado ahora de: y = y + y  = 4, 4
        Su estado ahora de: x = x + 1 = 5, 4
    */
}