#include <stdio.h>
#include <stdbool.h>

int main(void){

    int x, y ,z,tempB = 0,tempW = 0;
    bool b = tempB;
    bool w = tempW;
    

    //Ingresamos valores
    printf("Ingrese su x : \n");
    scanf("%d", &x);

    printf("Ingrese su y: \n");
    scanf("%d", &y);

    printf("Ingrese su z: \n");
    scanf("%d", &z);

    printf("Ingrese su b : \n");
    scanf("%d", &tempB);

    printf("Ingrese su w: \n");
    scanf("%d", &tempW);

    //Resolvemos
    printf("El resultado de x %% 4 == 0 = %d\n", (x%4) == 0 );

    printf("El resultado de x + y == 0 && y - x == (-1) * z = %d\n",x + y == 0 && y - x == (-1) * z );

    printf("El resultado de not b && w = %d\n", !b && w);

    return 0;

    /*Ingrese su x :
        4
        Ingrese su y:
        -4
        Ingrese su z:
        8
        Ingrese su b :
        1
        Ingrese su w:
        1
        El resultado de x % 4 == 0 = 1
        El resultado de x + y == 0 && y - x == (-1) * z = 1
        El resultado de not b && w = 0
    */
}