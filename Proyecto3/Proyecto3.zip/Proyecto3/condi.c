#include <stdio.h>
    
int main (void){    
    // Condicional 1E,F

    int x = 0, y = 0;

    // Solicitar al usuario que ingrese los valores de x e y
    printf("Ingrese el valor de x: \n");
    scanf("%d", &x);

    printf("Ingrese el valor de y: \n");
    scanf("%d", &y);

    // Imprimir los valores de los estados iniciales
    printf("El valor de los estados iniciales es: %d, %d\n", x, y);

    // Comprobar la condición x >= y
    if (x >= y) {
        x = 0;
        printf("El valor de los estados si x >= y es: %d, %d\n", x, y);
    } else { // Si x <= y
        x = 2;
        printf("El valor de los estados si x <= y es: %d, %d\n", x, y);
    }

    /*(Ejecucion Condicial F)
        Ingrese el valor de x:
        -100
        Ingrese el valor de y:
        1
        El valor de los estados iniciales es: -100, 1
         El valor de los estados si x <= y es: 2, 1
    */

     //CONDICIONAL EJERCICIO 2

    int z,m;

    printf("Ingrese un valor para x: \n");
    scanf("%d", &x);

    printf("Ingrese un valor para y: \n");
    scanf("%d", &y);

    printf("Ingrese un valor para z: \n");
    scanf("%d", &z);

    printf("Ingrese un valor para m: \n");
    scanf("%d", &m);

    printf("(o0) Sus estados iniciales son: %d,%d,%d,%d\n", x,y,z,m);

    if(x<y){
        printf("Como x < y su estado es: \n");
        m = x;
    }else{
        printf("Como x>=y, su estado es : \n");
        m = y;
    }
    printf("(o1) sus estados queda como: %d,%d,%d,%d\n",x,y,z,m);

    if( m < z){

        printf("Como m < z, su estado es: \n");
        //Skip

    }else{
        printf("Como m>=z, su estado es: \n");
        m = z;
    }
    printf(" (o2) Sus estados quedan como: %d,%d,%d,%d \n", x,y,z,m);

        return 0;
    
    //Ejecucion 
    /*
        Ingrese un valor para x:
        5
        Ingrese un valor para y:
        4
        Ingrese un valor para z:
        8
        Ingrese un valor para m:
        0
        (o0) Sus estados iniciales son: 5,4,8,0
        Como x>=y, su estado es :
        (o1) sus estados queda como: 5,4,8,4
        Como m < z, su estado es:
        (o2) Sus estados quedan como: 5,4,8,4
    
        (Ejecucion con otros estados iniciales cualesquiera)
    
        Ingrese un valor para x:
        5
        Ingrese un valor para y:
        2
        Ingrese un valor para z:
        4
        Ingrese un valor para m:
        7
        (o0) Sus estados iniciales son: 5,2,4,7
        Como x>=y, su estado es :
        (o1) sus estados queda como: 5,2,4,2
        Como m < z, su estado es:
        (o2) Sus estados quedan como: 5,2,4,2

        Transfoma a m haciedolo mas chico
    */

    return 0;
}
    
